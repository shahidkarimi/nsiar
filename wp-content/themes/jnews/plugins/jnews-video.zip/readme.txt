Change Log :

== 9.0.2 ==
- [BUG] Fix 3 dot toggle header filter

== 9.0.1 ==
- [IMPROVEMENT] Improve script loader without boost mode

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.4 ==
- [BUG] Fix sanitize data

== 8.0.3 ==
- [IMPROVEMENT] Change video block styling

== 8.0.2 ==
- [BUG] Fix video carousel 1 responsive issue

== 8.0.1 ==
- [IMPROVEMENT] Frontend video submit button for mobile

== 8.0.0 ==
- [IMPROVEMENT] Compatible with JNews v8.0.0

== 7.1.0 ==
- [BUG] Fix string translation

== 7.0.9 ==
- [BUG] Fix buddy press member navigation
- [BUG] Fix fatal error upon JNews theme not activated

== 7.0.8 ==
- [IMPROVEMENT] Replace .bind() with .on()
- [IMPROVEMENT] Replace .unbind() with .off()

== 7.0.7 ==
- [IMPROVEMENT] Replace .ready() with .on()

== 7.0.6 ==
- [BUG] Change .load to .on
- [BUG] Load plugin text domain

== 7.0.5 ==
- [BUG] Change jquery live to bind

== 7.0.4 ==
- [IMPROVEMENT] Add remaining quota if WooCommerce mode used

== 7.0.3 ==
- [BUG] Fix String Translation

== 7.0.2 ==
- [IMPROVEMENT] Better animation for login form popup

== 7.0.1 ==
- [IMPROVEMENT] Block and Carousel Video support normal post
- [BUG] Fix warning message on buddypress 6.0.0

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.6 ==
- [BUG] Fix video following style issue in video post template

== 6.0.5 ==
- [BUG] Fix notification popup style issue

== 6.0.4 ==
- [BUG] Fix naming folder issue
- [BUG] Fix issue with implode() function PHP 7.4

== 6.0.3 ==
- [IMPROVEMENT] Only load the style and script files when needed

== 6.0.2 ==
- [IMPROVEMENT] Change default only search video post to disable

== 6.0.1 ==
- [BUG] Fix active plugin issue
- [BUG] Fix customizer JNews Video empty

== 6.0.0 ==
- First Release
