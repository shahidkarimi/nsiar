Change Log :

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.0 ==
- [IMPROVEMENT] Compatible with JNews v8.0.0

== 7.0.2 ==
- [IMPROVEMENT] Replace .ready() with .on()
- [BUG] Fix undefined constant

== 7.0.1 ==
- [IMPROVEMENT] Auto adjustment override single post

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.1 ==
- [IMPROVEMENT] Use .on()

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
