Change Log :

== 9.0.1 ==
- [BUG] Fix missing review widget in Elementor issue

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.2 ==
- [BUG] Fix Sanitize request

== 8.0.1 ==
- [BUG] Fix null price

== 8.0.0 ==
- [IMPROVEMENT] Compatible with JNews v8.0.0

== 7.0.2 ==
- [BUG] Fix currency on review price float

== 7.0.1 ==
- [BUG] Fix price not showing correctly

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.1 ==
- [BUG] Fix rating, pro cons, and price not showing

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.3 ==
- [IMPROVEMENT] Update rating value when edit post

== 5.0.2 ==
- [IMPROVEMENT] Add price currency option
- [IMPROVEMENT] Add brand product name option

== 5.0.1 ==
- [IMPROVEMENT] Compatible with Jeg Framework

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0
- [IMPROVEMENT] Compatible with PHP 7.2 and higher

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.1.0 ==
- Add capability to add review without rating

== 1.0.0 ==
- First Release
