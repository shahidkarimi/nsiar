<?php
/**
 * @author      Jegtheme
 * @license     https://opensource.org/licenses/MIT
 */
namespace Jeg\Customizer\Section;

/**
 * Default Settings
 */
class Helper_Section extends \WP_Customize_Section {}

