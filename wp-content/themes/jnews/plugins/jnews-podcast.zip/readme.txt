Change Log :

== 9.0.2 ==
- [BUG] Fix share position in media menu section

== 9.0.1 ==
- [BUG] Fix podcast play button issue

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.3 ==
- [IMPROVEMENT] Update series counter

== 8.0.2 ==
- [BUG] Fix sanitize data

== 8.0.1 ==
- [BUG] Fix Podcast block shortcode issue

== 8.0.0 ==
- First Release
