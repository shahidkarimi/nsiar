<?php

if ( class_exists( 'WPBakeryShortCodesContainer' ) && is_admin() )
{
	class WPBakeryShortCode_Jnews_Element_Socialiconwrapper extends \WPBakeryShortCodesContainer {}

	class WPBakeryShortCode_Jnews_Element_Socialcounterwrapper extends \WPBakeryShortCodesContainer {}
}